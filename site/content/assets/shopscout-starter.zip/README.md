# ShopScout shopping-agent starter

Requires Node.js 20+. Official package: https://github.com/forgemeshlabs/shopscout-mcp
Live contract: https://shopscout.forgemesh.io/openapi.json

## Start without spending

```sh
node shopscout-discover.mjs
# Optional: exercise the unsigned payment gate, with no wallet or payment:
node shopscout-discover.mjs --check-payment-gate
```

The first command reads two public discovery endpoints. The second also sends one unsigned POST to /v1/search and expects HTTP 402. Neither script signs or pays. They do not prove paid search or settlement works.

## MCP

Merge the `shopscout` entry from mcp-config.json into your client's supported configuration. It launches the published stdio package with npx; review packages before running them. The host must support local stdio MCP. The hosted /mcp URL currently exposes discovery/list_tools only, not the paid tools.

No private key is included. get_capabilities works; paid tools return payment_required. To enable paid tools intentionally, follow the official README and provide WALLET_PRIVATE_KEY through protected client configuration using a dedicated, low-balance Base wallet with USDC. Do not commit the key. The signer does not load .env files itself.

SHOPSCOUT_MAX_PRICE_USD limits a single call. Your host must separately enforce aggregate spend and call limits. This kit is a discovery/configuration starter, not a full agent runtime or checkout system.

## Request examples

- search-example.json: body for POST /v1/search or arguments for search_products.
- shipping-example.json: body for POST /v1/shipping/compare or arguments for compare_shipping_plans. Entirely synthetic; no merchant coverage or live price claim.
- AGENT-INSTRUCTIONS.md: suggested task policy; enforce controls in host code.

The shipping example compares $49 + $12 shipping with $55 + $0 shipping. Pre-tax known totals are $61 and $55. Unknown taxes/duties remain unknown. Do not submit synthetic rules as though they were real merchant terms.

The four paid operations currently cost $0.01 each. Free discovery does not perform a purchase. ShopScout does not place orders or run the planned watches. Check live capabilities for changes.
