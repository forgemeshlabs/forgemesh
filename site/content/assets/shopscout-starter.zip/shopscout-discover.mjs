#!/usr/bin/env node
// Node 20+. No credentials, signing, payment headers, or paid retry logic.
const origin = 'https://shopscout.forgemesh.io';
const gate = process.argv.includes('--check-payment-gate');
if (process.argv.slice(2).some(arg => arg !== '--check-payment-gate')) {
  throw new Error('Usage: node shopscout-discover.mjs [--check-payment-gate]');
}
async function request(path, options = {}) {
  return fetch(origin + path, {
    ...options,
    redirect: 'error',
    signal: AbortSignal.timeout(15000),
    headers: { accept: 'application/json', ...options.headers },
  });
}
for (const path of ['/v1/capabilities', '/openapi.json']) {
  const response = await request(path);
  if (!response.ok) throw new Error(`${path}: HTTP ${response.status}`);
  const body = await response.json();
  if (path === '/openapi.json') {
    for (const route of ['/v1/search', '/v1/products/get', '/v1/compare', '/v1/shipping/compare']) {
      if (!body.paths?.[route]?.post) throw new Error(`Contract missing POST ${route}`);
    }
    console.log('OpenAPI: all four expected POST routes found');
  } else {
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('Invalid capabilities response');
    console.log('Capabilities: JSON object received; inspect the endpoint for current availability');
  }
}
if (gate) {
  const response = await request('/v1/search', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ query: 'compact coffee grinder', country: 'US', currency: 'USD', limit: 3 }),
  });
  await response.arrayBuffer();
  if (response.status !== 402) throw new Error(`Expected unsigned search to return 402; received ${response.status}`);
  console.log('Unsigned search: HTTP 402 received; no payment submitted');
}
console.log('Discovery check complete. No paid functionality was tested.');
